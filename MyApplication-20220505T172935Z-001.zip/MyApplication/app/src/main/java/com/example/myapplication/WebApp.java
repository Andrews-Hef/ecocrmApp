package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;


public class WebApp extends AppCompatActivity {

    //variable
    EditText editText;
    private WebView mywebView;
    //appelle du fichier de sauvegarde des données
    SharedPreferences  preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_app);

        //faire le lien entre le front end et le back end par l'id
        editText =findViewById(R.id.siteEdit);

        //recuperation de la données sauvegardé dans le document
        preferences = getSharedPreferences("SHARED_PREF",MODE_PRIVATE);
        String name =preferences.getString("site","");

        //affichage du crm en fonction du nom rentré de l'utilisateur
        mywebView=(WebView)findViewById(R.id.webview);
        mywebView.setWebViewClient(new WebViewClient());
        mywebView.loadUrl("https://www.ecocrm.fr/"+name+"/admin");
        WebSettings webSettings=mywebView.getSettings();
        webSettings.setJavaScriptEnabled(true);

    }

    // active l'affichage de certains element de la page web
    public class mywebClient extends WebViewClient{
        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon){
            super.onPageStarted(view,url,favicon);
        }
        @Override
        //
        public boolean shouldOverrideUrlLoading(WebView view,String url){
            view.loadUrl(url);
            return true;
        }
    }
    @Override
    public void onBackPressed(){
        if(mywebView.canGoBack()) {
            mywebView.goBack();
        }
        else{
            super.onBackPressed();
        }
    }
}
