package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

//affichage du crm
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;

//sauvegarde du site
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.CheckBox;

import java.net.URL;

public class MainActivity extends AppCompatActivity {

    //variable pour la sauvegarde du site
     TextView textView;
     EditText editText;
    CheckBox mRemember;
     Button saveButton;
    boolean isRemembered = false;
    //données sauvegardé
    public static final String SHARED_PREFS = "sharedPrefs";
    public static final String TEXT = "text";
    private String text;

    SharedPreferences sharedPreferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //les variables = les id du front end
        textView = (TextView) findViewById(R.id.site);
        editText = (EditText) findViewById(R.id.siteEdit);
        mRemember =findViewById(R.id.check);
        saveButton = (Button) findViewById(R.id.btnSave);

        //mode private pour que les autres applis n'ai pas accès au données et definition du fichier ou sera sauvegardé les données
        sharedPreferences = getSharedPreferences( "SHARED_PREF", MODE_PRIVATE);

        //se souvenir du choix du site crm
        isRemembered = sharedPreferences.getBoolean("CHECKBOX",false);
        if (isRemembered){
            //appel de la class qui gere l'affichage du crm(page web)
            Intent intent= new Intent(MainActivity.this,WebApp.class);
            startActivity(intent);
            finish();
        }
        // action sur le clique du bouton sauvegarder
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //transforme le texte en string
                String site = editText.getText().toString();
                //verifie la condition du boutons
                boolean checked = mRemember.isChecked();
                //controle de saisie pour qu'on puissent pas rentrer d'url a l'interieur
                 if(site.contains("http://")||site.contains("https://")|| site.contains(".com")||site.contains(".fr")){
                     //affichage de l'erreur en message flash
                     Toast.makeText(MainActivity.this,"Erreur! Veuillez rentrez votre identifiant.",Toast.LENGTH_LONG).show();
                 }else {

                     // preparation des données a sauvegarder
                     SharedPreferences.Editor editor = sharedPreferences.edit();
                     editor.putString("site", site);
                     editor.putBoolean("CHECKBOX", checked);
                     //enregistrement des données
                     editor.apply();
                     //affichage message flash si c'est sauvegardé
                     Toast.makeText(MainActivity.this, "Site sauvegardé!", Toast.LENGTH_SHORT).show();
                     //appel de la class qui gere l'affichage du crm(page web)
                     Intent intent = new Intent(MainActivity.this, WebApp.class);
                     startActivity(intent);
                     finish();
                 }
            }
        });



    }

}